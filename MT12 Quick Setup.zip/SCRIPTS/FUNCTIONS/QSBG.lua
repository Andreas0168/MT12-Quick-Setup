﻿local absPWM = 100
local absFreq = 2
local absActive = 0
local brakeState = 1
local brakeRate = 100
local brakeCnt = 0

local ltRun = 0
local ltLastSwitch = 0
local ltDiff = 0
local speakCnt = 0

local vscActive = 0
local forwardRate = 0

qs_srcStrVal = 0
qs_srcThrVal = 0
qs_chnStrVal = 0
qs_chnThrVal = 0

local function run()
	if not qs_sourceThr or not qs_drvMode then return end
	qs_srcStrVal = getSourceValue(qs_sourceStr)
	qs_chnStrVal = getOutputValue(qs_chnStr)
	qs_srcThrVal = getSourceValue(qs_sourceThr)
	qs_chnThrVal = getOutputValue(qs_chnThr)

	if qs_ltActive == 1 then			-- Laptime active?
		local Time = getTime()
		if speakCnt > 0 then speakCnt = speakCnt - 1 end
		local switch = getSourceValue(qs_ltSwitch == 0 and qs_sourceSB or qs_sourceSC) < 0 and 0 or 1
		local ltNum = #qs_ltList + 1
		if ltNum <= 1000 then
			if ltRun == 0 then				-- waiting to start
				if qs_srcThrVal >= 950 then
					ltRun = 1
					if ltNum == 1 then
						qs_ltList[ltNum] = Time
						ltDiff = 0
						qs_ltBest = 1000000
					else
						ltDiff = Time - qs_ltList[ltNum - 1]
					end
					playFile('start.wav')
				end
			elseif ltRun == 1 then
				local t = Time - ltDiff
				local t2 = t - qs_ltList[ltNum - 1]
				qs_ltLapTime = t2
				if ltLastSwitch == 0 and switch == 1 then
					if t2 >= qs_ltTW then
						qs_ltList[ltNum] = t
						if t2 < qs_ltBest then qs_ltBest = t2 end
						qs_playSignal(1000, 50)
						local m = math.floor(t2 / 6000)
						t2 = t2 - m * 6000
						if speakCnt == 0 then
							speakCnt = 79
							if m > 0 then playNumber(m, 36) end
							playNumber(t2, 37, PREC2)
							playFile('lap.wav')
							playNumber(ltNum - 1, 0)
						end
					end
				end
			end
		else
			qs_ltActive = 0
		end
		ltLastSwitch = switch
	else
		ltRun = 0
		qs_ltLapTime = nil
	end

	local r, g, b = 0, 0, 0

	if qs_ACC[1] == 1 then
		if qs_srcThrVal >= 20 then r, b = 255, 255
		elseif qs_srcThrVal <= -20 then r = 255
		end
	end

	if qs_VSC[1] == 1 then
		if qs_srcThrVal > 50 then
			local reduce = 1026 - (qs_srcStrVal < 0 and -qs_srcStrVal or qs_srcStrVal)
			reduce = forwardRate * ((1 - qs_VSC[2]) * reduce / 1024 + qs_VSC[2])
			model.setGlobalVariable(2, qs_drvMode, reduce)
			vscActive = 1
		else
			if vscActive == 1 then
				model.setGlobalVariable(2, qs_drvMode, forwardRate)
				vscActive = 0
			end
			forwardRate = model.getGlobalVariable(2, qs_drvMode)
		end
	else
		if vscActive == 1 then
			model.setGlobalVariable(2, qs_drvMode, forwardRate)
			vscActive = 0
		end
		forwardRate = model.getGlobalVariable(2, qs_drvMode)
	end

	if qs_ABS[1] == 1 then
		local reduce = qs_ABS[6]
		if qs_ABS[11] == 1 then
			reduce = qs_srcStrVal < 0 and -qs_srcStrVal or qs_srcStrVal
			if qs_ABS[12] > 0 then
				reduce = (reduce / 10.24) >= qs_ABS[12] and qs_ABS[6] or brakeRate
			else
				reduce = (1 - qs_ABS[6]) * ((1024 - reduce) / 1024) + qs_ABS[6]
			end
		end
		if qs_srcThrVal <= qs_ABS[5] then
			absActive = 1
			if qs_ABS[3] == 1 then
				if absFreq > 1 then
					absFreq = absFreq - 1
					brakeCnt = 2
				else
					absFreq = qs_ABS[10]
					local subtr = qs_ABS[4] == 1 and 100 - qs_ABS[9] or qs_ABS[9]
					absPWM = absPWM - subtr
					brakeState = absPWM > 0 and 1 or 0
					if absPWM < 1 then absPWM = absPWM + 100 end
					if qs_ABS[4] == 1 then brakeState = 1 - brakeState end
					brakeCnt = 1
				end
			end
			if brakeCnt > 1 then
				brakeCnt = brakeCnt - 1
			else
				if brakeState == 1 then
					model.setGlobalVariable(3, qs_drvMode, brakeRate)
					brakeCnt = qs_ABS[7]
					brakeState = 0
				else
					model.setGlobalVariable(3, qs_drvMode, brakeRate * reduce)
					brakeCnt = qs_ABS[8]
					brakeState = 1
				end
			end
			if brakeState == 0 then r, g, b = 0, 255, 255
				if qs_ABS[2] == 1 then qs_playSignal(161, 20) end
			end
		else
			if absActive == 1 then
				model.setGlobalVariable(3, qs_drvMode, brakeRate)
				absActive = 0
			end
			brakeRate = model.getGlobalVariable(3, qs_drvMode)
			absPWM, absFreq = 100, 1
			brakeState = 1 - qs_ABS[4]
			brakeCnt = 1
		end
	else
		if absActive == 1 then
			model.setGlobalVariable(3, qs_drvMode, brakeRate)
			absActive = 0
		end
		brakeRate = model.getGlobalVariable(3, qs_drvMode)
	end

	local bright = (qs_srcThrVal < 0 and -qs_srcThrVal or qs_srcThrVal) / 1024
	setRGBLedColor(0, r * bright, g * bright, b * bright)
end

local function background()
end

local function init()
	local fn = '/SCRIPTS/FUNCTIONS/QSBG.lua' if fstat(fn) then del(fn) end
end

return { run = run, init = init, background = background}
